drop table aq_dossier cascade constraints;
drop table dossier_Releases cascade constraints;
drop sequence S_dossier_releaseId;
drop sequence hibernate_sequence;
