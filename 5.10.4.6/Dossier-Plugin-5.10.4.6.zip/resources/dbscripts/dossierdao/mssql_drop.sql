drop table aq_dossier;
drop table dossier_Releases;
