alter table comment_TitleText drop constraint FK_CT_commentEntry;
DROP INDEX IDX_CT_commentEntry
	ON comment_TitleText;
DROP INDEX IDX_CE_ReferenceId
	ON comment_Entries;
DROP INDEX IDX_CE_ApplicationId
	ON comment_Entries;
DROP INDEX IDX_CE_UserId
	ON comment_Entries;
DROP INDEX IDX_CE_Date
	ON comment_Entries;
drop table comment_TitleText;
drop table comment_Releases;
drop table comment_Entries;