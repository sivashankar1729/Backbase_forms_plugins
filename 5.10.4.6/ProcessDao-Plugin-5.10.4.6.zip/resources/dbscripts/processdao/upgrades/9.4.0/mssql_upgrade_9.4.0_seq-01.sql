-- MSSQL upgrade script for the ProcessDAO plugin of Blueriq release 9.4.0
--
-- Adds 'on delete cascade' statements to various pre-existing foreign keys.
-- 
-- Needs to be executed on Blueriq databases for versions before 9.4.0.

alter table attributeValues drop constraint FK_AV_InstanceAttributes;
alter table attributeValues with nocheck add constraint FK_AV_InstanceAttributes foreign key (instanceAttributeId) references instanceAttributes on delete cascade;
alter table customFields drop constraint FK_CustomFields_Tasks;
alter table customFields with nocheck add constraint FK_CustomFields_Tasks foreign key (taskId) references tasks on delete cascade;
alter table instanceAttributes drop constraint FK_IA_Instances;
alter table instanceAttributes with nocheck add constraint FK_IA_Instances foreign key (instanceId) references instances on delete cascade;
alter table instances drop constraint FK_Instances_Cases;
alter table instances with nocheck add constraint FK_Instances_Cases foreign key (caseId) references cases on delete cascade;
alter table roles drop constraint FK_Roles_Tasks;
alter table roles with nocheck add constraint FK_Roles_Tasks foreign key (taskId) references tasks on delete cascade;
alter table tasks drop constraint FK_Tasks_Cases;
alter table tasks with nocheck add constraint FK_Tasks_Cases foreign key (caseId) references cases on delete cascade;
alter table teams drop constraint FK_Teams_Tasks;
alter table teams with nocheck add constraint FK_Teams_Tasks foreign key (taskId) references tasks on delete cascade;
alter table users drop constraint FK_Users_Tasks;
alter table users with nocheck add constraint FK_Users_Tasks foreign key (taskId) references tasks on delete cascade;

INSERT INTO process_Releases (version, releasedate, description) VALUES('9.4.0 seq-01', CURRENT_TIMESTAMP, 'Adds on delete cascade statements.');
