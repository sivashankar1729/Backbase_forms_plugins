create index IDX_Events_Case_Task on events (caseId, taskId);
create index IDX_DelayedEvents_Case_Event on delayedEvents (caseId, eventId);

insert into process_Releases (version, releasedate, description) VALUES('9.6.2 seq-01', CURRENT_TIMESTAMP(), 'Adds indexes on events(caseId, taskId) and delayedEvents(caseId, eventId).');