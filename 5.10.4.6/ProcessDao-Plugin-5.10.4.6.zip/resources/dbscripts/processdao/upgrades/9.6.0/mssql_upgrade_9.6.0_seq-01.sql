create table delayedEvents (id numeric(19,0) identity not null, caseId numeric(19,0) not null, eventId numeric(19,0) not null, primary key (id));
create table events (id numeric(19,0) identity not null, applicationId varchar(255) null, content text null, name varchar(255) not null, replayedEventId numeric(19,0) null, status varchar(10) not null, taskId numeric(19,0) null, timestamp datetime null, type varchar(7) not null, userName varchar(255) null, caseId numeric(19,0) null, primary key (id));

alter table delayedEvents add constraint FK_Delayed_Events foreign key (eventId) references events on delete cascade;
alter table events add constraint FK_Events_Cases foreign key (caseId) references cases on delete cascade;

create table unauthorized_users (id numeric(19,0) identity not null, userId varchar(255) null, taskId numeric(19,0) not null, primary key (id));
create index IDX_Unauthorized_User_Tasks on unauthorized_users (taskId);
alter table unauthorized_users add constraint FK_Unauthorized_Users_Tasks foreign key (taskId) references tasks on delete cascade;

insert into process_Releases (version, releasedate, description) VALUES('9.6.0 seq-01', CURRENT_TIMESTAMP, 'Adds support for case events.');
insert into process_Releases (version, releasedate, description) VALUES('9.6.0 seq-02', CURRENT_TIMESTAMP, 'Adds support for task authorization.');

create index IDX_Events_Case_Task on events (caseId, taskId);
create index IDX_DelayedEvents_Case_Event on delayedEvents (caseId, eventId);