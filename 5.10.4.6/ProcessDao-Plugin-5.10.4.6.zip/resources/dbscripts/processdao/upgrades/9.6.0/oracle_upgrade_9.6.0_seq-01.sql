create table delayedEvents (id number(19,0) not null, caseId number(19,0) not null, eventId number(19,0) not null, primary key (id));
create table events (id number(19,0) not null, applicationId varchar2(255 char), content clob, name varchar2(255 char) not null, replayedEventId number(19,0), status varchar2(10 char) not null, taskId number(19,0), timestamp timestamp, type varchar2(7 char) not null, userName varchar2(255 char), caseId number(19,0), primary key (id));
alter table delayedEvents add constraint FK_Delayed_Events foreign key (eventId) references events on delete cascade;
alter table events add constraint FK_Events_Cases foreign key (caseId) references cases on delete cascade;
create sequence events_s;

create table unauthorized_users (id number(19,0) not null, userId varchar2(255 char), taskId number(19,0) not null, primary key (id));
create index IDX_Unauthorized_User_Tasks on unauthorized_users (taskId);
alter table unauthorized_users add constraint FK_Unauthorized_Users_Tasks foreign key (taskId) references tasks on delete cascade;

INSERT INTO process_Releases (id, version, releasedate, description) VALUES (S_process_releaseId.NEXTVAL, '9.6.0 seq-01', SYSDATE, 'Adds support for case events.');
INSERT INTO process_Releases (id, version, releasedate, description) VALUES (S_process_releaseId.NEXTVAL, '9.6.0 seq-01', SYSDATE, 'Adds support for task authorization.');

create index IDX_Events_Case_Task on events (caseId, taskId);
create index IDX_DelayedEvents_Case_Event on delayedEvents (caseId, eventId);