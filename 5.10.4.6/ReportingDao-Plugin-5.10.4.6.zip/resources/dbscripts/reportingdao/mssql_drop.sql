drop table reports;
drop table reports_releases;