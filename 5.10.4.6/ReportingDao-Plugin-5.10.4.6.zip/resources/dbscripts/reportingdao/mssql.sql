create table reports (id numeric(19,0) identity not null, source_application varchar(255) not null, export_xml text not null, source_service varchar(255) not null, creation_datetime datetime not null, user_name varchar(255), primary key (id));
create table reports_releases (id numeric(19,0) identity not null, description varchar(150) null, releaseDate datetime not null, version varchar(100) not null, primary key (id));

insert into reports_releases (version, releasedate, description) VALUES('9.7.0', CURRENT_TIMESTAMP, 'Initial release');
