blueriq.webFileUploadTemplateFactory = function(viewModel, bindingContext) {
	if(viewModel && viewModel.type === 'webFileUpload') {
		return 'core/webfileupload/template/webfileupload';
	}
};
if(bqApp) {
	bqApp.templateFactory.registerModelHandler(blueriq.webFileUploadTemplateFactory);
}

blueriq.webFileUploadModelFactory = function(model, context) {
	if(model && model.type === 'container' && model.contentStyle === 'webfile_upload') {
		return new WebFileUploadModel(model,context);
	}
};
if(bqApp) {
	bqApp.modelFactory.register(blueriq.webFileUploadModelFactory);
}

function WebFileUploadModel(model, context) {
	var self = this;
	
	this.browserSupported = window.FormData != undefined;
	
	blueriq.models.ContainerModel.call(self, model, context);
	
	this.type = 'webFileUpload';
	
	this.buttonText = context.session.getModel(model.children[0]).caption;
			
	this.file = ko.observable();
	this.fileObjectURL = ko.observable();	
	this.attributeName = context.session.getModel(model.children[0]).name;	

	this.fileUploadTextItem = ko.observable();
	
	this.update = function WebFileUploadModelUpdate(model) {						
		if(model.children[1] !== undefined)
			self.fileUploadTextItem(context.modelFactory.createViewModel(context.session.getModel(model.children[1]), context));
	};
		
	this.upload = function() {		
		var fd = new FormData();
	    fd.append('file', self.file());
	    fd.append('elementName', self.attributeName);
	    fd.append('pageEvent', JSON.stringify(context.session.createPageEvent()));
	    	    
	    $.ajax({
	    	type: 'POST',
	    	url: new blueriq.QueryStringBuilder(bqApp.configuration.baseUri + context.session.id + '/api/subscription/' + context.subscriptionId + '/webfileupload/handle')
	    				.param('X-CSRF-Token', context.session.csrfToken()).toUrl(),
	        contentType: false,
	        cache: false,
	        processData: false,
	        data: fd,
	        success: function (data) {
	            context.eventHandler.handleEvents(true, data);
		    },
		    error: function() {
		        context.eventHandler.handleEvents(false);
		    }
	    });
	};
};

var windowURL = window.URL || window.webkitURL;
ko.bindingHandlers.file = {
    init: function(element, valueAccessor) {
        $(element).change(function() {
        	if(this.files) {
	            var file = this.files[0];
	            if (ko.isObservable(valueAccessor())) {
	                valueAccessor()(file);
	            }
        	}
        });
    },

    update: function(element, valueAccessor, allBindingsAccessor) {
        var file = ko.utils.unwrapObservable(valueAccessor());
        var bindings = allBindingsAccessor();

        if (bindings.fileObjectURL && ko.isObservable(bindings.fileObjectURL)) {
            var oldUrl = bindings.fileObjectURL();
            if (oldUrl) {
                windowURL.revokeObjectURL(oldUrl);
            }
            bindings.fileObjectURL(file && windowURL.createObjectURL(file));
        }

        if (bindings.fileBinaryData && ko.isObservable(bindings.fileBinaryData)) {
            if (!file) {
                bindings.fileBinaryData(null);
            } else {
                var reader = new FileReader();
                reader.onload = function(e) {
                    bindings.fileBinaryData(e.target.result);
                };
                reader.readAsArrayBuffer(file);
            }
        }
    }
};