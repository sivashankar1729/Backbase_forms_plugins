create table trace_Timeline (id number(19,0) not null, action varchar2(100 char), caseId number(19,0), name varchar2(100 char), traceDate timestamp, type varchar2(100 char), typeId varchar2(255 char), userId varchar2(100 char), userName varchar2(100 char), primary key (id));

-- insert task messages
insert into trace_timeline(action, tracedate, type, userId, username, name, caseId, typeId) 
  select entries.type, entries.tracedate, 'task', values1.stringvalue, values2.stringvalue, values3.stringvalue, values4.integervalue, values5.integervalue
  from trace_entries entries 
      left join trace_properties keys1 on entries.id = keys1.traceentryid and keys1.name = 'userid'
      left join trace_propertyvalues values1 on keys1.id=values1.traceentrypropertyid 
      left join trace_properties keys2 on entries.id = keys2.traceentryid and keys2.name = 'username' 
      left join trace_propertyvalues values2 on keys2.id=values2.traceentrypropertyid 
      left join trace_properties keys3 on entries.id = keys3.traceentryid and keys3.name = 'displayname'
      left join trace_propertyvalues values3 on keys3.id=values3.traceentrypropertyid 
      left join trace_properties keys4 on entries.id = keys4.traceentryid and keys4.name = 'caseid'
      left join trace_propertyvalues values4 on keys4.id=values4.traceentrypropertyid 
      left join trace_properties keys5 on entries.id = keys5.traceentryid  and keys5.name = 'taskid'
      left join trace_propertyvalues values5 on keys5.id=values5.traceentrypropertyid 
  where entries.type = 'taskAssignmentUpdated' or entries.type = 'taskCompleted';
      
-- insert case messages
insert into trace_timeline(action, tracedate, type, userId, username, name, caseId, typeId) 
  select entries.type, entries.tracedate, 'case', values1.stringvalue, values2.stringvalue, values3.stringvalue, values4.integervalue, values4.integervalue
  from trace_entries entries 
      left join trace_properties keys1 on entries.id = keys1.traceentryid and keys1.name = 'userid'
      left join trace_propertyvalues values1 on keys1.id=values1.traceentrypropertyid 
      left join trace_properties keys2 on entries.id = keys2.traceentryid and keys2.name = 'username' 
      left join trace_propertyvalues values2 on keys2.id=values2.traceentrypropertyid 
      left join trace_properties keys3 on entries.id = keys3.traceentryid and keys3.name = 'processname'
      left join trace_propertyvalues values3 on keys3.id=values3.traceentrypropertyid 
      left join trace_properties keys4 on entries.id = keys4.traceentryid and keys4.name = 'caseid'
      left join trace_propertyvalues values4 on keys4.id=values4.traceentrypropertyid 
  where entries.type = 'caseCreated' or entries.type = 'caseCompleted';
  
-- insert document message
insert into trace_timeline(action, tracedate, type, userId, username, name, caseId, typeId) 
  select entries.type, entries.tracedate, 'document', values1.stringvalue, values2.stringvalue, values3.stringvalue, values4.integervalue, values5.stringvalue
  from trace_entries entries 
      left join trace_properties keys1 on entries.id = keys1.traceentryid and keys1.name = 'userid'
      left join trace_propertyvalues values1 on keys1.id=values1.traceentrypropertyid 
      left join trace_properties keys2 on entries.id = keys2.traceentryid and keys2.name = 'username' 
      left join trace_propertyvalues values2 on keys2.id=values2.traceentrypropertyid 
      left join trace_properties keys3 on entries.id = keys3.traceentryid and keys3.name = 'documentname'
      left join trace_propertyvalues values3 on keys3.id=values3.traceentrypropertyid 
      left join trace_properties keys4 on entries.id = keys4.traceentryid and keys4.name = 'caseid'
      left join trace_propertyvalues values4 on keys4.id=values4.traceentrypropertyid 
      left join trace_properties keys5 on entries.id = keys5.traceentryid and keys5.name = 'documentid'
      left join trace_propertyvalues values5 on keys5.id=values5.traceentrypropertyid 
  where entries.type = 'documentCreated' or 
        entries.type = 'documentUpdated' or 
        entries.type = 'documentDeleted' or 
        entries.type = 'documentMoved' or 
        entries.type = 'documentReceived' or 
        entries.type = 'documentMetadataUpdated';
        
-- insert message event
insert into trace_timeline(action, tracedate, type, userId, username, name, caseId, typeId) 
  select entries.type, entries.tracedate, 'mesageevent', values1.stringvalue, values2.stringvalue, values3.stringvalue, values4.integervalue, values5.stringvalue
  from trace_entries entries 
      left join trace_properties keys1 on entries.id = keys1.traceentryid and keys1.name = 'userid'
      left join trace_propertyvalues values1 on keys1.id=values1.traceentrypropertyid 
      left join trace_properties keys2 on entries.id = keys2.traceentryid and keys2.name = 'username' 
      left join trace_propertyvalues values2 on keys2.id=values2.traceentrypropertyid 
      left join trace_properties keys3 on entries.id = keys3.traceentryid and keys3.name = 'messageeventname'
      left join trace_propertyvalues values3 on keys3.id=values3.traceentrypropertyid 
      left join trace_properties keys4 on entries.id = keys4.traceentryid and keys4.name = 'caseid'
      left join trace_propertyvalues values4 on keys4.id=values4.traceentrypropertyid 
      left join trace_properties keys5 on entries.id = keys5.traceentryid  and keys5.name = 'messageeventid'
      left join trace_propertyvalues values5 on keys5.id=values5.traceentrypropertyid
  where entries.type = 'messageEventReceived';


