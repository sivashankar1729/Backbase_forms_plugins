-- MSSQL script for the updating trace_Timeline table

-- modifiy table structure: add new column applicationId
alter table trace_Timeline add applicationId varchar(255);

-- add correct value to applicationId
update t 
set t.applicationId = e.applicationId
from trace_Timeline t, trace_PropertyValues pv, trace_Properties p, trace_Entries e
where t.caseId = pv.integerValue and pv.traceEntryPropertyId = p.id and p.name='caseid'
and e.id = p.traceEntryId;