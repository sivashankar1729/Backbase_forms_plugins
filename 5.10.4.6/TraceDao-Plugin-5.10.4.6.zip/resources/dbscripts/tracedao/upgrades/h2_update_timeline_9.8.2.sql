-- H2 script for the updating trace_Timeline table

-- modifiy table structure: add new column applicationId
alter table trace_Timeline add applicationId varchar(255);

-- add correct value to applicationId
update trace_timeline t
set t.applicationId = 
(select distinct e.applicationId
from trace_PropertyValues pv, trace_Properties p, trace_Entries e
where t.caseId = pv.integerValue and pv.traceEntryPropertyId = p.id and p.name='caseid' and e.id = p.traceEntryId);
