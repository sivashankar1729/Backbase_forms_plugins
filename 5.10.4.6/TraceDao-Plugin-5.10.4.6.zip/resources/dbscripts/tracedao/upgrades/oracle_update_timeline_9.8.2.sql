-- ORACLE script for the updating trace_Timeline table

-- modifiy table structure: add new column applicationId
alter table trace_Timeline add applicationId varchar2(255 char);

-- add correct value to applicationId
merge into trace_Timeline t using 
(select distinct e.applicationId entryAppId, pv.integerValue integerValue from trace_PropertyValues pv, trace_Properties p, trace_Entries e
		where pv.traceEntryPropertyId = p.id and p.name='caseid' and e.id = p.traceEntryId) on (t.caseId = integerValue)
when matched then
update set t.applicationId = entryAppId;