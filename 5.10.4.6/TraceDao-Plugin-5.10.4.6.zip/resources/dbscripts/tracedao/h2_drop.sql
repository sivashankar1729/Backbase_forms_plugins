alter table trace_Properties drop constraint FK_EP_traceEntry;
alter table trace_PropertyValues drop constraint FK_PV_traceEntryProperty;
drop table trace_Properties if exists;
drop table trace_PropertyValues if exists;
drop table trace_Releases if exists;
drop table trace_Entries if exists;
drop table trace_Timeline if exists;
