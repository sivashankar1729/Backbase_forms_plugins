drop index idx_user_tasks on users;
create index idx_users_tasks on users (taskId, userName);

drop index idx_role_tasks on roles;
create index idx_roles_tasks on roles (taskId, role);

drop index idx_team_tasks on teams;
create index idx_teams_tasks on teams (taskId, team);

drop index idx_unauthorized_user_tasks on unauthorized_users;
create index idx_unauthorized_users_tasks on unauthorized_users (taskId, userId);

insert into process_Releases (version, releasedate, description) VALUES('9.9.0 seq-01', CURRENT_TIMESTAMP, 'Replaces indexes on taskId in users/roles/teams with composite indexes.');

create table cases_displaynames (id numeric(19,0) identity not null, displayname varchar(255), language varchar(20), caseId numeric(19,0));
create index IDX_DisplayNames_Cases on cases_displaynames (caseId);
alter table cases_displaynames add constraint FK_DisplayNames_Cases foreign key (caseId) references cases on delete cascade;

create table tasks_displaynames (id numeric(19,0) identity not null, displayname varchar(255), language varchar(20), taskId numeric(19,0));
create index IDX_DisplayNames_Tasks on tasks_displaynames (taskId);
alter table tasks_displaynames add constraint FK_DisplayNames_Tasks foreign key (taskId) references tasks on delete cascade;
