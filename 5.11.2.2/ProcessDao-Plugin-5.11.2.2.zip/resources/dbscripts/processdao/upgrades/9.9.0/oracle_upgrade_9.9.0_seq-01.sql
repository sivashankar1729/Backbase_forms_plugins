drop index idx_user_tasks;
create index idx_users_tasks on users (taskId, userName);

drop index idx_role_tasks;
create index idx_roles_tasks on roles (taskId, role);

drop index idx_team_tasks;
create index idx_teams_tasks on teams (taskId, team);

drop index idx_unauthorized_user_tasks;
create index idx_unauthorized_users_tasks on unauthorized_users (taskId, userId);

INSERT INTO process_Releases (id, version, releasedate, description) VALUES (S_process_releaseId.NEXTVAL, '9.9.0 seq-01', SYSDATE, 'Replaces indexes on taskId in users/roles/teams with composite indexes.');

create table cases_displaynames (id number(19,0) not null, displayname varchar2(255 char), language varchar2(20 char), caseId number(19,0));
create index IDX_DisplayNames_Cases on cases_displaynames (caseId);
alter table cases_displaynames add constraint FK_DisplayNames_Cases foreign key (caseId) references cases on delete cascade;
create sequence casesdisplaynames_s;

create table tasks_displaynames (id number(19,0) not null, displayname varchar2(255 char), language varchar2(20 char), taskId number(19,0));
create index IDX_DisplayNames_Tasks on tasks_displaynames (taskId);
alter table tasks_displaynames add constraint FK_DisplayNames_Tasks foreign key (taskId) references tasks on delete cascade;
create sequence tasksdisplaynames_s;