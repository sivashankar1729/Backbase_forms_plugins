-- MSSQL upgrade script for the ProcessDAO plugin of Blueriq release 9.2.6
--
-- Adds various indexes.
-- 
-- Needs to be executed on Blueriq databases for versions equal to or before 9.2.5.

CREATE INDEX IDX_Cases_AppId       ON cases (applicationId);
CREATE INDEX IDX_Cases_Status      ON cases (status);
CREATE INDEX IDX_Cases_LockedBy    ON cases (lockedBy);
CREATE INDEX IDX_CustomField_Name  ON customFields (name);
CREATE INDEX IDX_IA_AttributeName  ON instanceAttributes (attributeName);
CREATE INDEX IDX_Instances_IName   ON instances (instanceName);
CREATE INDEX IDX_Instances_EName   ON instances (entityName);
CREATE INDEX IDX_Tasks_Type        ON tasks (type);
CREATE INDEX IDX_Tasks_LastCheck   ON tasks (lastPriorityCheck);
CREATE INDEX IDX_Tasks_TimeoutDate ON tasks (timeoutDate);
CREATE INDEX IDX_Tasks_Status      ON tasks (status);
CREATE INDEX IDX_Tasks_ParentId    ON tasks (parentId);
CREATE INDEX IDX_Tasks_NodeId      ON tasks (nodeId);

CREATE TABLE process_Releases (id numeric(19,0) identity not null, description varchar(150) null, releaseDate datetime not null, version varchar(100) not null, primary key (id));
INSERT INTO process_Releases (version, releasedate, description) VALUES('9.2.6 seq-01', CURRENT_TIMESTAMP, 'Adds various indexes');
