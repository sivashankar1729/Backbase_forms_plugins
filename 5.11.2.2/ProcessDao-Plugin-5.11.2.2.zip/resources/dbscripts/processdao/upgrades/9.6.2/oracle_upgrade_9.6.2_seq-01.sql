create index IDX_Events_Case_Task on events (caseId, taskId);
create index IDX_DelayedEvents_Case_Event on delayedEvents (caseId, eventId);

INSERT INTO process_Releases (id, version, releasedate, description) VALUES (S_process_releaseId.NEXTVAL, '9.6.2 seq-01', SYSDATE, 'Adds indexes on events(caseId, taskId) and delayedEvents(caseId, eventId).');