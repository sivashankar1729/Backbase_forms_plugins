create index IDX_AV_ValueType 		on attributeValues (valueType);

create index IDX_AV_Type 			on attributeValues (type);
create index IDX_AV_BooleanValue 	on attributeValues (booleanValue);
create index IDX_AV_CurrencyValue 	on attributeValues (currencyValue);
create index IDX_AV_DateTimeValue	on attributeValues (dateTimeValue);
create index IDX_AV_DateValue 		on attributeValues (dateValue);
create index IDX_AV_EntityValue		on attributeValues (entityValue);
create index IDX_AV_IntegerValue	on attributeValues (integerValue);
create index IDX_AV_NumberValue		on attributeValues (numberValue);
create index IDX_AV_PercentageValue	on attributeValues (percentageValue);
create index IDX_AV_StringValue		on attributeValues (stringValue);

insert into process_Releases (version, releasedate, description) VALUES('9.8.5 seq-01', CURRENT_TIMESTAMP(), 'Adds indexes on attributeValues.');