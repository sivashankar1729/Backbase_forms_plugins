-- H2 upgrade script for the ProcessDAO plugin of Blueriq release 9.4.0
--
-- Adds 'on delete cascade' statements to various pre-existing foreign keys.
-- 
-- Needs to be executed on Blueriq databases for versions before 9.4.0.

alter table attributeValues drop constraint FK_AV_InstanceAttributes;
alter table attributeValues add constraint FK_AV_InstanceAttributes foreign key (instanceAttributeId) references instanceAttributes on delete cascade nocheck;
alter table customFields drop constraint FK_CustomFields_Tasks;
alter table customFields add constraint FK_CustomFields_Tasks foreign key (taskId) references tasks on delete cascade nocheck;
alter table instanceAttributes drop constraint FK_IA_Instances;
alter table instanceAttributes add constraint FK_IA_Instances foreign key (instanceId) references instances on delete cascade nocheck;
alter table instances drop constraint FK_Instances_Cases;
alter table instances add constraint FK_Instances_Cases foreign key (caseId) references cases on delete cascade nocheck;
alter table roles drop constraint FK_Roles_Tasks;
alter table roles add constraint FK_Roles_Tasks foreign key (taskId) references tasks on delete cascade nocheck;
alter table tasks drop constraint FK_Tasks_Cases;
alter table tasks add constraint FK_Tasks_Cases foreign key (caseId) references cases on delete cascade nocheck;
alter table teams drop constraint FK_Teams_Tasks;
alter table teams add constraint FK_Teams_Tasks foreign key (taskId) references tasks on delete cascade nocheck;
alter table users drop constraint FK_Users_Tasks;
alter table users add constraint FK_Users_Tasks foreign key (taskId) references tasks on delete cascade nocheck;

INSERT INTO process_Releases (version, releasedate, description) VALUES('9.4.0 seq-01', CURRENT_TIMESTAMP(), 'Adds on delete cascade statements.');
