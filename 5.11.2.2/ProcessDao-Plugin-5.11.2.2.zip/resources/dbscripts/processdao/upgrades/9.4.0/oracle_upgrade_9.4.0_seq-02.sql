-- Oracle upgrade script for the ProcessDAO plugin of Blueriq release 9.4.0
--
-- Adds various indexes that work with lower-case text data.
-- 
-- Needs to be executed on Blueriq databases for versions before 9.4.0.

CREATE INDEX IDX_IA_AttributeName_low ON instanceAttributes (LOWER(attributeName)); 
CREATE INDEX IDX_Cases_AppId_low ON cases (LOWER(applicationId)); 
CREATE INDEX IDX_Tasks_Status_low ON tasks (LOWER(status)); 
CREATE INDEX IDX_Tasks_EventName_low ON tasks (LOWER(eventName)); 
CREATE INDEX IDX_Tasks_Type_low ON tasks (LOWER(type)); 

INSERT INTO process_Releases (id, version, releasedate, description) VALUES (S_process_releaseId.NEXTVAL, '9.4.0 seq-02', SYSDATE, 'Adds lower-case indexes.');

