-- MSSQL upgrade script for the ProcessDAO plugin of Blueriq release 9.4.0
--
-- Adds various indexes that work with lower-case text data.
-- 
-- Needs to be executed on Blueriq databases for versions before 9.4.0.

ALTER TABLE instanceAttributes ADD attributeName_lower AS LOWER(attributeName);
CREATE INDEX IDX_IA_AttributeName_low ON instanceAttributes (attributeName_lower); 
ALTER TABLE cases ADD applicationId_lower AS LOWER(applicationId);
CREATE INDEX IDX_Cases_AppId_low ON cases (applicationId_lower); 
ALTER TABLE tasks ADD status_lower AS LOWER(status);
CREATE INDEX IDX_Tasks_Status_low ON tasks (status_lower); 
ALTER TABLE tasks ADD eventName_lower AS LOWER(eventName);
CREATE INDEX IDX_Tasks_EventName_low ON tasks (eventName_lower); 
ALTER TABLE tasks ADD type_lower AS LOWER(type);
CREATE INDEX IDX_Tasks_Type_low ON tasks (type_lower); 

INSERT INTO process_Releases (version, releasedate, description) VALUES('9.4.0 seq-02', CURRENT_TIMESTAMP, 'Adds lower-case indexes.');
