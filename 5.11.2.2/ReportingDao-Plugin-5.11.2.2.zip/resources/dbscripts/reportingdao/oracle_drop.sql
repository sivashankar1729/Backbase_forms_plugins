drop table REPORTS;
drop table REPORTS_RELEASES;