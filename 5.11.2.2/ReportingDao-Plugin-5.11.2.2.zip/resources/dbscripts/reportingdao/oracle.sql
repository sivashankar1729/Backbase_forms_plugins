-- we need the / separator because the create trigger
-- operation will not work without the ; and the thin jdbc
-- uses ; as statement separator by default

create table reports (id number(19,0) not null, source_application varchar2(255 char) not null, export_xml clob not null, source_service varchar2(255 char) not null, creation_datetime timestamp not null, user_name varchar2(255 char), primary key (id))
/
create sequence S_reports_id
/

-- oracle prior to 12c does not support auto increment fields so we set it in a trigger
-- since hibernate is not used when inserting records
create or replace trigger reports_id
before insert on reports
for each row
begin
	select S_reports_id.nextval into :new.id from dual;
end;
/

alter trigger reports_id enable
/

create table reports_releases (id number(19,0) not null, description varchar2(150 char), releaseDate timestamp not null, version varchar2(100 char) not null, primary key (id))
/
create sequence reports_releases_s
/

insert into reports_releases (id, version, releasedate, description) VALUES (reports_releases_s.nextval, '9.7.0', SYSDATE, 'Initial release')
/