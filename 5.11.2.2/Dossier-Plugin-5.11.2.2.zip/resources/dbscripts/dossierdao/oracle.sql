CREATE TABLE aq_dossier (id number(19,0) not null, date1 timestamp, date2 timestamp, feature1 varchar2(50 char), feature2 varchar2(50 char), feature3 varchar2(50 char), feature4 varchar2(50 char), profileXml clob not null, type varchar2(255 char), primary key (id));
CREATE TABLE dossier_Releases (id number(19,0) not null, description varchar2(150 char), releaseDate timestamp not null, version varchar2(100 char) not null, primary key (id));
CREATE SEQUENCE S_dossier_releaseId;
CREATE SEQUENCE hibernate_sequence;
INSERT INTO dossier_Releases (id, version, releasedate, description) VALUES(S_dossier_releaseId.NEXTVAL, '9.2.6 seq-01', SYSDATE, 'Adds table in which database updates are tracked.');
