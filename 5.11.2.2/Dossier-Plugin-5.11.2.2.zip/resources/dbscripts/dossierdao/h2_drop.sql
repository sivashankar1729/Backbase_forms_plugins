drop table aq_dossier if exists;
drop table dossier_Releases if exists;
