alter table comment_TitleText drop constraint FK_CT_commentEntry;
drop index IF EXISTS IDX_CT_commentEntry;
drop index IF EXISTS IDX_CE_ReferenceId;
drop index IF EXISTS IDX_CE_ApplicationId;
drop index IF EXISTS IDX_CE_UserId;
drop index IF EXISTS IDX_CE_Date;
drop table if exists comment_TitleText;
drop table if exists comment_Releases;
drop table if exists comment_Entries;
