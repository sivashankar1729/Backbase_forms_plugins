create table trace_DisplayNameValues (id number(19,0) not null, displayName varchar2(255 char) not null, languageCode varchar2(19 char) not null, timelineId number(19,0) null, primary key (id));
alter table trace_DisplayNameValues add constraint FK_Timeline_DNV foreign key (timelineId) references trace_Timeline on delete cascade;
create sequence S_trace_displaynamevalues;
