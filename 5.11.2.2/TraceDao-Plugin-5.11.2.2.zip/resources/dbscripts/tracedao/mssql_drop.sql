alter table trace_Properties drop constraint FK_EP_traceEntry;
alter table trace_PropertyValues drop constraint FK_PV_traceEntryProperty;
drop table trace_Properties;
drop table trace_PropertyValues;
drop table trace_Releases;
drop table trace_Entries;
drop table trace_Timeline;
alter table trace_DisplayNameValues drop constraint FK_Timeline_DNV;
drop table trace_DisplayNameValues;
